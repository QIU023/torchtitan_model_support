rc=0 step: 20  loss:  3.16421  grad_norm:  0.7373
