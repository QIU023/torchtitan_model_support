rc=0 
